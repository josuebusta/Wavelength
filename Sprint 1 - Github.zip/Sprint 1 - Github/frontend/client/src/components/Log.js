// src/components/Log.js
import React, { useState } from 'react';
import {useNavigate } from "react-router-dom";
import './Log.css';

const Log = () => {
  const albumData = {
    title: "Absolute Elsewhere",
    artist: "Blood Incantation",
    year: 2024,
    coverImage: '/images/image 5.png', // Replace with the actual path to the album cover image
  };

  const [listenedToDate, setListenedToDate] = useState(false);
  const [listenedBefore, setListenedBefore] = useState(false);
  const navigate = useNavigate();

  const handleSubmit = (e) => {
    e.preventDefault();
    alert("Album logged successfully!");
    navigate('/albumdetailslogged')
  };

    const handleCancel = (e) => {
        e.preventDefault();
        const confirmCancel = window.confirm("Are you sure you'd like to cancel? Your diary log will not be saved.");
        if (confirmCancel) {
        navigate('/albumdetails');
        }
  };

  return (
    <div className="log-container">
      <h1 className="app-title">Wavelength</h1>
      
      <div className="log-content">
        <div
          className="album-cover"
          style={{ backgroundImage: `url(${albumData.coverImage})` }}
        ></div>

        <div className="album-details">
          <p className="listened-to">I listened to...</p>
          <h2 className="album-title">{albumData.title}</h2>
          <p className="album-artist">{albumData.artist}</p>
          <p className="album-year">{albumData.year}</p>

          <form onSubmit={handleSubmit}>
            <label>
              <input
                type="checkbox"
                checked={listenedToDate}
                onChange={() => setListenedToDate(!listenedToDate)}
              />
              Listened to on 10/21/2024
            </label>
            <label>
              <input
                type="checkbox"
                checked={listenedBefore}
                onChange={() => setListenedBefore(!listenedBefore)}
              />
              I’ve listened to this album before
            </label>

            <div className="button-group">
              <button type="submit" className="submit-button">Submit</button>
              <button onClick={handleCancel} className="cancel-button">Cancel</button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};

export default Log;