import React from "react";
import "../App.css";


const HomePage = () => {
    return (
        <div className="homepage">
            <header className="header">
                <h1>
                <a href="/homepage" nav>Wave<span>length</span></a>
                </h1>
            </header>

        <section className="popular-section">
        <div className="section-header">
            <h2>Popular albums today</h2>
        </div>
        <div className="album-list">
            <div className="album">
                <img src="/images/Short 'N Sweet.png" alt="Short n' Sweet" />
                <p className="album-title">Short n' Sweet</p>
                <p className="artist-name">Sabrina Carpenter</p>
            </div>
            <div className="album">
                <img src="/images/Brat and it's.png" alt="Brat and it's completely different but also still Brat" width={225}/>
                <p className="album-title">Brat and it's completely different...</p>
                <p className="artist-name">Charli XCX</p>
            </div>
            <div className="album">
                <img src="/images/Rise and Fall.png" alt="The Rise and Fall of a Midwest Princess" width={225}/>
                <p className="album-title">The Rise and Fall of a Midwest Pri...</p>
                <p className="artist-name">Chappell Roan</p>
            </div>
            <div className="album">
                <img src="/images/Hit Me Hard.png" alt="HIT ME HARD AND SOFT" />
                <p className="album-title">HIT ME HARD AND SOFT</p>
                <p className="artist-name">Billie Eilish</p>
            </div>
            <div className="album">
                <img src="/images/The Tortured Poet's.png" alt="THE TORTURED POETS DEPART" />
                <p className="album-title">THE TORTURED POETS DEPART...</p>
                <p className="artist-name">Taylor Swift</p>
            </div>
            </div>
        </section>

        <section className="popular-section">
        <div className="section-header">
            <h2>Recently released</h2>
        </div>
        <div className="album-list">
            <div className="album">
                <img src="/images/image 6.png" alt="Songs of a Lost World" />
                <p className="album-title">Songs of a Lost World</p>
                <p className="artist-name">The Cure</p>
            </div>
            <div className="album">
                <img src="/images/image 7.png" alt="The Night The Zombies Came" width={225}/>
                <p className="album-title">The Night The Zombies Came</p>
                <p className="artist-name">The Pixies</p>
            </div>
            <div className="album">
                <img src="/images/image (1).png" alt="Cartoon Darkness" width={225}/>
                <p className="album-title">Cartoon Darkness</p>
                <p className="artist-name">Amyl and the Sni...</p>
            </div>
            <div className="album">
                <img src="/images/image (2).png" alt="Fate and Alcohol" />
                <p className="album-title">Fate and Alcohol</p>
                <p className="artist-name">Japandroids</p>
            </div>
            <div className="album">
                <img src="/images/image (3).png" alt="I Want Blood" />
                <p className="album-title">I Want Blood</p>
                <p className="artist-name">Jerry Cantrell</p>
            </div>
            </div>
        </section>
    </div>
  );
};

export default HomePage;