import React from "react";
import "../App.css";


const HomePage = () => {
    return (
        <div className="homepage">
            <header className="header">
                <h1>
                    <a href="/homepage" nav>Wave<span>length</span></a>
                </h1>
            </header>

        <section className="popular-section">
        <div className="section-header">
            <h2>Popular albums today</h2>
            <a href="/discover" className="discover-link" nav>Discover more→</a>
        </div>
        <div className="album-list">
            <div className="album">
                <img src="/images/Short 'N Sweet.png" alt="Short n' Sweet" />
                <p className="album-title">Short n' Sweet</p>
                <p className="artist-name">Sabrina Carpenter</p>
            </div>
            <div className="album">
                <img src="/images/Brat and it's.png" alt="Brat and it's completely different but also still Brat" width={225}/>
                <p className="album-title">Brat and it's completely different...</p>
                <p className="artist-name">Charli XCX</p>
            </div>
            <div className="album">
                <img src="/images/Rise and Fall.png" alt="The Rise and Fall of a Midwest Princess" width={225}/>
                <p className="album-title">The Rise and Fall of a Midwest Pri...</p>
                <p className="artist-name">Chappell Roan</p>
            </div>
            <div className="album">
                <img src="/images/Hit Me Hard.png" alt="HIT ME HARD AND SOFT" />
                <p className="album-title">HIT ME HARD AND SOFT</p>
                <p className="artist-name">Billie Eilish</p>
            </div>
            <div className="album">
                <img src="/images/The Tortured Poet's.png" alt="THE TORTURED POETS DEPART" />
                <p className="album-title">THE TORTURED POETS DEPART...</p>
                <p className="artist-name">Taylor Swift</p>
            </div>
            </div>
        </section>

      <section className="featured-section">
        <h2>Featured album</h2>
        <div className="featured-album">
          <a href="/albumdetails"><img src="/images/image 5.png" alt="Absolute Elsewhere" /></a>
          <div className="album-info">
            <h3>Absolute Elsewhere</h3>
            <p className="artist-name">Blood Incantation</p>
            <p className="release-date">October 4, 2024</p>
            <p className="album-description">
              Absolute Elsewhere, the latest release by Blood Incantation, presents an ambitious sonic departure from the Denver death metal band's established sound. Known for their blend of cosmic death metal, Blood Incantation has taken a sharp left turn into the ambient genre, delivering an album that is contemplative, experimental, and introspective.
            </p>
          </div>
        </div>
      </section>
    </div>
  );
};

export default HomePage;