// src/components/AlbumDetails.js
import React from 'react';
import { Link } from 'react-router-dom';
import '../AlbumData.css';

const AlbumDetails = () => {
  const albumData = {
    title: "Absolute Elsewhere",
    artist: "Blood Incantation",
    year: 2024,
    description:
      "Absolute Elsewhere, the latest release by Blood Incantation, presents an ambitious sonic departure from the Denver death metal band's established sound. Known for their blend of cosmic death metal, Blood Incantation has taken a sharp left turn into the ambient genre, delivering an album that is contemplative, experimental, and introspective. Gone are the intricate riffs, punishing blast beats, and guttural growls that defined albums like Hidden History of the Human Race. Instead, Absolute Elsewhere leans entirely into expansive, synthesizer-driven soundscapes that channel the cosmic themes the band has always explored, but in a more atmospheric, meditative way.",
    coverImage: '/images/image 5.png' // Replace with the actual path to the album cover image
  };

  return (
    <div className="album-details">
      <Link to="/homepage" className="back-link">← Back to Home Page</Link>
      
      <div className="album-info">
        <div
          className="album-cover"
          style={{ backgroundImage: `url(${albumData.coverImage})` }}
        ></div>

        <div className="album-text">
          <h1>{albumData.title}</h1>
          <p className="artist">{albumData.artist}</p>
          <p className="year">{albumData.year}</p>
          <p className="description">{albumData.description}</p>
        </div>
      </div>

      <div className="log-button">
        <Link to="/log">
          <button id="log-album">Log Album</button>
        </Link>
      </div>
    </div>
  );
};

export default AlbumDetails;