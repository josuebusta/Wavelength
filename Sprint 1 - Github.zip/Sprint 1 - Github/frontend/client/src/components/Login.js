import React, {useState} from "react";
import axios from "axios";
import {useNavigate } from "react-router-dom";

axios.get("http://localhost:5000/api/protected-endpoint", {
    headers: {
        Authorization: `Bearer ${localStorage.getItem("token")}`,
    },
});


const Login = () => {
    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");
    const navigate = useNavigate();

    const handleLogin = async (e) => {
        e.preventDefault();
        try {
            const response = await axios.post("http://localhost:5000/api/auth/login", {email, password});
            alert("Login successful!");

            const token = response.data.token
            localStorage.setItem('token', token);

            navigate('/homepage')
        } catch (error) {
            alert("Login failed: " + (error.response?.data?.message || error.message));
        }
    };

    const handleCancel = () => {
        navigate("/");
    };

    return (
        <div className="login-page">
            <div className="left-side"></div>
            <div className="right-side">
            <h1>
            Wave<span>length</span>
            </h1>
                <form className="login-form" onSubmit={handleLogin}>
                    <label>Email</label>
                    <input
                        type="email"
                        placeholder="Email"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        required
                    />
                    <label>Password</label>
                    <input
                        type="password"
                        placeholder="Password"
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        required
                    />
                    <button type="Submit" className="btn">Sign In</button>
                    <button type="button" className="btn cancel-btn" onClick={handleCancel}>
                        Cancel
                    </button>
                </form>
            </div>
        </div>
    );
};

export default Login;