// src/components/Welcome.js
import React from "react";
import { Link } from "react-router-dom";

const Welcome = () => {
  return (
    <div className="welcome-page">
      <div className="left-side"></div>
      <div className="right-side">
        <h1>
          Wave<span>length</span>
        </h1>
        <p>Your personal music diary and discovery platform - all in one place</p>
        <div className="button-container">
          <Link to="/login" className="btn">Sign in</Link>
          <Link to="/register" className="btn">Register</Link>
        </div>
      </div>
    </div>
  );
};

export default Welcome;
