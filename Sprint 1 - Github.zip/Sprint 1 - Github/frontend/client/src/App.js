import './App.css';
import { BrowserRouter as Router, Routes, Route } from "react-router-dom"; 
import React from "react";
import Login from "./components/Login";
import Welcome from './components/Welcome';
import Register from './components/Register';
import HomePage from './components/HomePage';
import Discover from './components/Discover';
import AlbumDetails from './components/AlbumDetails';
import AlbumDetailsLogged from './components/AlbumDetailsLogged';
import Log from './components/Log';


const App = () => (
  <Router>
    <div className='App'>
      <Routes>
        <Route path='/' element={<Welcome />} />
        <Route path='/login' element={<Login />} />
        <Route path='/register' element={<Register />} />
        <Route path='/homepage' element={<HomePage />} />
        <Route path='/discover' element={<Discover />} />
        <Route path='/albumdetails' element={<AlbumDetails />} />
        <Route path='/albumdetailslogged' element={<AlbumDetailsLogged />} />
        <Route path='/log' element={<Log />} />
      </Routes>
    </div>
  </Router>
)

export default App;
